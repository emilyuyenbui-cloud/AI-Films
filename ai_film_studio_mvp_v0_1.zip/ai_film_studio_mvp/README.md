
# AI Film Studio MVP v0.1

A local production UI built around the workflow structure:

Idea → Asset Bible → Scene Planner (`分镜策划`) → Video Prompts (`视频提示词`) → ComfyUI Workflow Export

## What works in v0.1
- Create/save/load film projects
- Define project settings
- Manage Character / Voice / Prop / Location archives
- Create and edit micro-scenes (8–15s recommended)
- Import existing `分镜策划` JSON
- Generate schema-compatible `视频提示词`
- Export:
  - Project JSON
  - `分镜策划` JSON
  - `视频提示词` JSON
  - Full ComfyUI workflow JSON by replacing the `分镜策划` and `视频提示词` nodes in the template

## Run

```bash
cd ai_film_studio_mvp
python -m venv .venv
source .venv/bin/activate       # macOS/Linux
# .venv\Scripts\activate        # Windows
pip install -r requirements.txt
streamlit run app.py
```

Open the URL Streamlit prints in the terminal.

## Important design rule
Asset names must stay stable. The exact names used in:
- `角色档案`
- `道具档案`
- `场景档案`

should be reused in every scene's:
- `出现角色`
- `出现道具`
- `出现场景`

This is necessary for downstream asset/index matching.

## Next planned modules
1. Viral Story Engine
2. Automatic Asset Bible extraction
3. Storyboard generation
4. Continuity / Start-State / End-State engine
5. Locked visual references
6. Model adapters: Seedance / Kling / MiniMax / Veo
7. Take manager
8. Voice & sound manager
9. Final timeline / assembly
